import React from 'react';
import SentimentAnalyzer from './components/SentimentAnalyzer';

function App() {
  return (
    <div className="App">
      <SentimentAnalyzer />
    </div>
  );
}

export default App;
